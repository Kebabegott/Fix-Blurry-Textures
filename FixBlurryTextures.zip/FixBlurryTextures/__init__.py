bl_info = {
    "name": "Fix Blurry Minecraft Textures",
    "author": "v o o v",
    #blender version
    "blender": (3, 3, 0),
    #plugin version
    "version": (1, 0, 0),
    "location": "Properties > Render",
    "description": "Fixes blurry textures in Minecraft models",
    "warning": "",
    "wiki_url": "",
    "category": "Material",
}

import os
import bpy
import bpy.utils.previews

custom_icons = None

##################################################

#Panel
class MyPanel(bpy.types.Panel):
    bl_label = "Fix Blurry Minecraft Textures"
    bl_idname = "OBJECT_PT_my_panel"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "material"
    
    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.scale_y = 1.7
        row.operator("my.button", text="Unblur textures", icon_value=custom_icons["custom_icon"].icon_id)


class MyButton(bpy.types.Operator):
    bl_idname = "my.button"
    bl_label = "My Button"
    
    def execute(self, context):
        for mat in bpy.data.materials:
            if mat.node_tree:
                for node in mat.node_tree.nodes:
                    if node.type == 'TEX_IMAGE':
                        node.interpolation = 'Closest'
        return {'FINISHED'}
    
##################################################

#Sidebar

Sidebar_name = "Unblur Textures" 

class MyPanel2(bpy.types.Panel):
    bl_label = "Fix Blurry Minecraft Textures"
    bl_idname = "OBJECT_PT_my_panel_2"
    bl_region_type = "UI"  # specify the region type, this could be 'UI' for sidebar or 'TOOLS' for toolbar
    bl_space_type = "VIEW_3D" # specify the space type, this could be 'VIEW_3D' for 3D View or 'PROPERTIES' for Properties panel
    bl_category = Sidebar_name
    
    
    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.scale_y = 1.7
        row.operator("my.button", text="Unblur textures", icon_value=custom_icons["custom_icon"].icon_id)


class MyButton(bpy.types.Operator):
    bl_idname = "my.button"
    bl_label = "My Button"
    
    def execute(self, context):
        for mat in bpy.data.materials:
            if mat.node_tree:
                for node in mat.node_tree.nodes:
                    if node.type == 'TEX_IMAGE':
                        node.interpolation = 'Closest'
        return {'FINISHED'}
    
##################################################

def register():
    global custom_icons
    custom_icons = bpy.utils.previews.new()
    addon_path = os.path.dirname(os.path.abspath(__file__))
    icons_dir = os.path.join(addon_path, "icons")
    custom_icons.load("custom_icon", os.path.join(icons_dir, "icon.png"), 'IMAGE')
    bpy.utils.register_class(MyPanel2)
    bpy.utils.register_class(MyPanel)
    bpy.utils.register_class(MyButton)
    
def unregister():
    global custom_icons
    bpy.utils.previews.remove(custom_icons)
    bpy.utils.unregister_class(MyPanel2)
    bpy.utils.unregister_class(MyPanel)
    bpy.utils.unregister_class(MyButton)


if __name__ == "__main__":
    register()
